package com.mad.tute04;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    public static final int CAMERA = 0;
    public static final int CAMERA_REQUEST_CODE = 1889;

    public static final int CAMERA_REQUEST = 1888;
    android.widget.ImageView ImageView;
    Button Camera;
    String currentPhotoPath;
    private Object length;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageView = findViewById(R.id.imageView1);
        Camera = findViewById(R.id.CameraBtn);


        Camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askPermissionCameara();
            }
        });


    }

    private void askPermissionCameara() {
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,new String[] {Manifest.permission.CAMERA},CAMERA_REQUEST_CODE);

        }else {
            openCamera();

        }

    }



    private void openCamera() {
        Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(camera, CAMERA_REQUEST);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CAMERA_REQUEST){
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            ImageView.setImageBitmap(photo);

        }
    }
}

